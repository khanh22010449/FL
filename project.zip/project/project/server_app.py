"""pytorch: A Flower / PyTorch app."""

from flwr.common import Context, ndarrays_to_parameters
from flwr.server import ServerApp, ServerAppComponents, ServerConfig
from flwr.server.strategy import FedAvg, FedAdagrad,FedAdam
from project.task import AttentionModel, get_weights

arr = []

def server_fn(context: Context):
    # Read from config
    num_rounds = context.run_config["num-server-rounds"]
    fraction_fit = context.run_config["fraction-fit"]
    text_feature_dim = context.run_config["text_feature_dim"]
    image_feature_dim = context.run_config["image_feature_dim"]
    attention_dim = context.run_config["attention_dim"]

    # Initialize model parameters
    ndarrays = get_weights(AttentionModel(text_feature_dim, image_feature_dim, attention_dim)) 
    parameters = ndarrays_to_parameters(ndarrays)

    # Define strategy 
    strategy = FedAvg(
        fraction_fit=fraction_fit,
        fraction_evaluate=1.0, 
        min_available_clients=2,
        initial_parameters=parameters,
    )
    # print(f"strategy : {strategy}")

    config = ServerConfig(num_rounds=num_rounds)

    return ServerAppComponents(strategy=strategy, config=config)


# Create ServerApp
app = ServerApp(server_fn=server_fn)





