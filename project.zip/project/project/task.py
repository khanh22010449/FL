from datasets import load_dataset
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from itertools import chain
from torch.nn.utils.rnn import pad_sequence
from torchvision import models

from collections import OrderedDict

import requests
from io import BytesIO
from PIL import Image
import re
import matplotlib.pyplot as plt

import numpy as np
import torchvision
from torchvision.transforms import Compose, Normalize, ToTensor, Resize


from flwr_datasets import FederatedDataset
from flwr_datasets.partitioner import IidPartitioner
from datasets import Dataset
from flwr.common.logger import log
from logging import INFO

import warnings
from transformers import AutoTokenizer, DataCollatorWithPadding, AutoModel
from torch.optim import AdamW
import transformers
from datasets.utils.logging import disable_progress_bar, set_verbosity_info

warnings.filterwarnings("ignore", category=UserWarning)
warnings.filterwarnings("ignore", category=FutureWarning)
disable_progress_bar()
transformers.logging.set_verbosity_error()

set_verbosity_info()

import random

def download_image(link):
    try:
        response = requests.get(link)
        response.raise_for_status()
        img = Image.open(BytesIO(response.content)).convert("RGB")
        return img

    except requests.exceptions.RequestException as e :
        # print(f"Lỗi khi tải ảnh từ {link}: {e}")
        return None
    
def label_dict(name_data):

    ds = load_dataset(name_data)
    data = ds["train"]

    columns = list(data[0].keys())

    num_label = 10000
    name_labels = []
    labels = []
    name_col = []

    for s in columns:
        j = 0
        name = []
        label = []
        for i in range(len(data[s])):
            if data[s][i] is not None:
                if data[s][i] not in name:
                    name.append(data[s][i])
                    label.append(j)
                    j += 1

        if num_label > len(label):
            num_label = len(label)
            name_labels.append(name)
            labels.append(label)
            name_col.append(s)

    name_labels = name_labels[-1]
    labels = labels[-1]
    name_col = name_col[-1]

    label_dict = dict(zip(labels, name_labels))
    return label_dict, name_col

fds = None

def load_data(partition_id: int, num_partitions: int, name_data: str , model_name: str):
    global fds
    if fds is None:
        partitioner = IidPartitioner(num_partitions= num_partitions)
        fds = FederatedDataset(
            dataset = name_data,
            partitioners = {"train": partitioner} ,
        )
    # Chuẩn bị mô hình trích xuất đặc trưng cho hình ảnh
    image_model = models.resnet50(pretrained=True)
    image_model = torch.nn.Sequential(*list(image_model.children())[:-1])  # Xóa lớp cuối cùng (classifier)
    image_model.eval()

    # Chuẩn bị mô hình tokenizer cho văn bản
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    text_model = AutoModel.from_pretrained(model_name)
    text_model.eval()

    # Chia dữ liệu cho từng Client
    partition = fds.load_partition(partition_id)

    # Lấy các giá trị Columns
    columns = list(partition[0].keys())

    #Lấy ra các giá trị label và cột được chọn làm label
    dict_label, col_label = label_dict(name_data)

    # chia dữ liệu thành 2 tập Train và Test
    partition_train_test = partition.train_test_split(test_size=0.2, seed=42)

    # log(INFO, "pytorch_transforms ...")

    # Khởi tạo hàm Normalize Image
    pytorch_transforms = Compose(
        [Resize((32,32)) ,ToTensor(), Normalize((0.5,), (0.5,))]
    )
    # Hàm thực hiện Nomalize Image
    def extract_image_features(batch):
        image_features = []
        for img_url in batch["Poster_Link"]:
            img = download_image(img_url)
            if img is not None:
                img = pytorch_transforms(img).unsqueeze(0)  # Thêm batch dimension
                with torch.no_grad():
                    features = image_model(img).squeeze().numpy()  # Trích xuất đặc trưng
                image_features.append(features)
            else:
                image_features.append(None)
        batch["image_feature"] = image_features
        return batch

    partition_train_test = partition_train_test.map(extract_image_features, batched=True)

    # Nóa các dòng chứa giá trị None
    partition_train_test = partition_train_test.filter(lambda x: x["image_feature"] is not None)

    partition_train_test = partition_train_test.remove_columns(["Poster_Link"])



    # Khởi tạo Columns Label
    def create_labels(batch):
        labels_data = {}
        labels = []

        for label in batch[col_label]:
            if label is not None:
                for key, value in dict_label.items():
                    if label == value:
                        labels.append(key)
            else:
                labels.append(random.randint(0,15))
        labels_data["labels"] = labels
        batch.update(labels_data)
        return batch
    # Tạo một làm Label mới
    partition_train_test = partition_train_test.map(create_labels, batched=True)

    # Xóa cột làm columns
    partition_train_test = partition_train_test.remove_columns(col_label)

    remove_col = []

    def remove_None(batch):
        updated_batch = batch.copy()
        for col in partition_train_test['train'].column_names:
            if col in ["image_feature", "labels"]:
                continue

            columns = {}
            values = []
            value = None

            for x in updated_batch[col]:
                if x is not None:
                    value = x
                    break


            # log(INFO, f"Columns <<---- {col}  --->> {value}")
            for i in range(len(updated_batch[col])):

                if batch[col][i] is not None:
                    # print(batch[col][i]))
                    values.append(str(updated_batch[col][i]))

                else:
                    values.append(str(value))
            columns[f"new_{col}"] = values
            remove_col.append(col)
            updated_batch.update(columns)
        return updated_batch

    partition_train_test = partition_train_test.map(remove_None, batched=True)

    for x in remove_col:
        if x in list(partition_train_test['train'].column_names):
            partition_train_test = partition_train_test.remove_columns(x)

    new_columns = list(partition_train_test['train'].column_names)

    tokenizer = AutoTokenizer.from_pretrained(model_name)

    columns_to_tokenize = [col for col in new_columns if col not in ['image_feature', 'labels']]

    def tokenize_function(examples):
        # tokenized_data = {}
        for col in columns_to_tokenize:
            if col in examples:
                # Kiểm tra dữ liệu trong cột
                if isinstance(examples[col], list) and all(isinstance(x, str) for x in examples[col]):
                    text_features = []
                    for text in examples[col]:
                        if text:
                            tokens = tokenizer(
                                text,
                                truncation=True,
                                add_special_tokens=True,
                                max_length=128,
                                padding="max_length",
                                return_tensors="pt",
                            )
                            with torch.no_grad():
                                features = text_model(**tokens).last_hidden_state.mean(dim=1).squeeze().numpy()
                            text_features.append(features)
                        else:
                            text_features.append(None)
                    examples[f"{col}_features"] = text_features
            else:
                print(f"Warning: Column {col} not found in examples.")
        return examples

    partition_train_test = partition_train_test.map(tokenize_function, batched=True)

    for x in columns_to_tokenize:
        partition_train_test = partition_train_test.remove_columns(x)

    log(INFO, " CHECK BATCH ...")
    def custom_collator(batch):
        """
        Hàm collator để xử lý và lưu trữ đặc trưng hình ảnh, văn bản và nhãn.
        """
        collated_batch = {
            "image_features": [],
            "text_features": {},
            "labels": []
        }

        # Lặp qua từng mẫu trong batch
        for sample in batch:
            # Xử lý đặc trưng hình ảnh
            if sample.get("image_feature") is not None:
                collated_batch["image_features"].append(torch.tensor(sample["image_feature"]))
            
            # Xử lý đặc trưng văn bản
            for key, value in sample.items():
                if "_features" in key:  # Tìm các cột chứa đặc trưng văn bản
                    if key not in collated_batch["text_features"]:
                        collated_batch["text_features"][key] = []
                    if value is not None:
                        collated_batch["text_features"][key].append(torch.tensor(value))
                    else:
                        collated_batch["text_features"][key].append(torch.zeros_like(collated_batch["text_features"][key][-1]))

            # Xử lý nhãn
            if "labels" in sample:
                collated_batch["labels"].append(torch.tensor(sample["labels"]))

        # Padding các đặc trưng để phù hợp với batch
        if collated_batch["image_features"]:
            collated_batch["image_features"] = torch.stack(collated_batch["image_features"])

        for key in collated_batch["text_features"]:
            collated_batch["text_features"][key] = pad_sequence(
                collated_batch["text_features"][key],
                batch_first=True,
                padding_value=0.0
            )
        
        collated_batch["labels"] = torch.tensor(collated_batch["labels"])
        
        return collated_batch


    trainloader = DataLoader(partition_train_test["train"], batch_size=32, shuffle=True, collate_fn=custom_collator)

    testloader = DataLoader(partition_train_test["test"], batch_size=32, collate_fn=custom_collator)
    return trainloader, testloader
    


class AttentionModel(nn.Module):
    def __init__(self, text_feature_dim, image_feature_dim, attention_dim):
        super(AttentionModel, self).__init__()
        # Attention cho các đặc trưng văn bản
        self.text_attention = nn.MultiheadAttention(embed_dim=text_feature_dim, num_heads=4, batch_first=True)
        
        # Attention giữa văn bản và hình ảnh
        self.text_to_image_attention = nn.MultiheadAttention(embed_dim=attention_dim, num_heads=4, batch_first=True)
        
        # Fully Connected để gộp thông tin
        self.fc_text = nn.Linear(text_feature_dim, attention_dim)
        self.fc_image = nn.Linear(image_feature_dim, attention_dim)
        self.fc_final = nn.Linear(attention_dim, 17)  # Lớp đầu ra (ví dụ: phân loại nhãn)
        
    def forward(self, text_features, image_features):

        # Attention giữa các đặc trưng văn bản
        attn_text_out, _ = self.text_attention(text_features, text_features, text_features)
        
        # Biến đổi đặc trưng hình ảnh về cùng chiều với đặc trưng văn bản
        image_features = self.fc_image(image_features).unsqueeze(1)  # Thêm chiều thứ 2 [batch_size, 1, attention_dim]
        
        # Attention giữa đặc trưng văn bản và hình ảnh
        attn_text_image_out, _ = self.text_to_image_attention(
            self.fc_text(attn_text_out),  # Query: Văn bản
            image_features,              # Key
            image_features               # Value
        )
        
        # Gộp thông tin và tính toán đầu ra
        combined_features = attn_text_image_out.mean(dim=1)  # Tổng hợp theo chiều sequence
        output = self.fc_final(combined_features)
        
        return output
    

def train_model(model, trainloader, num_epochs, device):
    model.to(device)
    
    criterion = torch.nn.CrossEntropyLoss().to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=0.0001)

    model.train()
    total_loss = 0.0
    for epoch in range(num_epochs):
        

        for batch in trainloader:
            # Check if there are text features in the batch
            if not batch["text_features"]:  # If batch["text_features"] is empty
                continue  # Skip this batch and move to the next one

            text_features = torch.cat(
                [batch["text_features"][col].unsqueeze(1) for col in batch["text_features"]], dim=1
            ).to(device)

            image_features = batch["image_features"].to(device) 
            labels = batch["labels"].to(device)

            # Forward pass
            outputs = model(text_features, image_features)
            # Backward pass và tối ưu hóa
            optimizer.zero_grad()

            loss = criterion(outputs.squeeze(), labels.long()) 
            
            loss.backward()
            optimizer.step()

            total_loss += loss.item()

        # In ra loss mỗi epoch
    avg_loss = total_loss / len(trainloader)
    # print(f"Epoch {epoch+1}/{num_epochs}, Loss: {avg_loss:.4f}")
    return avg_loss

def test_model(model, testloadder, device):
    model.to(device)
    criterion = torch.nn.CrossEntropyLoss()
    correct, loss = 0, 0.0
    with torch.no_grad():
        for batch in testloadder:
            if not batch["text_features"]:  # If batch["text_features"] is empty
                continue  # Skip this batch and move to the next one

            text_features = torch.cat(
                [batch["text_features"][col].unsqueeze(1) for col in batch["text_features"]], dim=1
            ).to(device)

            # Sử dụng image_features trực tiếp vì nó đã là tensor
            # Remove unsqueeze(1) here, keep image_features 2-dimensional
            image_features = batch["image_features"].to(device) 
            labels = batch["labels"].to(device)
            outputs = model(text_features, image_features)
            loss += criterion(outputs, labels).item()
            correct += (torch.max(outputs.data, 1)[1] == labels).sum().item()
    accuracy = correct / len(testloadder.dataset)
    loss = loss / len(testloadder)
    # print(f"Accuracy {accuracy} <<<-->>>   loss: {loss}")
    return loss, accuracy

def get_weights(model):
    return [val.cpu().numpy() for _, val in model.state_dict().items()]


def set_weights(model, parameters):
    params_dict = zip(model.state_dict().keys(), parameters)
    state_dict = OrderedDict({k: torch.tensor(v) for k, v in params_dict})
    model.load_state_dict(state_dict, strict=True)